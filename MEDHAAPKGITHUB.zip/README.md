# Medha AI — Android APK

Upload this folder to GitHub and the APK builds itself. No Android Studio,
no Java, nothing to install on your computer.

## Steps (10 minutes, one time)

### 1. Make a GitHub repo
- Go to **github.com** -> sign in -> click **+** (top right) -> **New repository**
- Name: `medha-ai-apk`
- Choose **Public** -> **Create repository**

### 2. Upload these files
- On the new repo page click **"uploading an existing file"**
- Drag **everything inside this folder** (README.md, package.json,
  capacitor.config.json, the `www` folder, the `assets` folder, and the
  `.github` folder) into the browser
- Scroll down -> **Commit changes**

> Important: the hidden `.github` folder must be uploaded too. If Windows
> hides it, turn on **View -> Hidden items** in File Explorer first.

### 3. Wait for the build
- Click the **Actions** tab at the top of your repo
- You will see "Build Medha AI APK" running (yellow dot). It takes 5-10 minutes.
- When it turns green, you are done.

### 4. Get the APK
Two ways:
- **Releases** (easiest to share): go to the repo home page, right side ->
  **Releases** -> latest -> download **Medha-AI.apk**. This link can be
  shared with anyone.
- **Actions**: open the finished run -> **Artifacts** -> `Medha-AI-APK`

### 5. Install on a phone
Send the `.apk` on WhatsApp. On the phone, open it and allow
"Install from unknown sources" when asked.

## Updating the app later
Replace `www/index.html` in the repo with the new version and commit.
A new APK builds automatically.

## Notes
- The whole app is inside the APK, so it does **not** depend on any website
  or on your laptop being on.
- It does need internet, because the AI runs on Google's servers.
